<?php
// local conenection

$servername = "127.0.0.12:4306";
$username = "root";
$password = "1234567890";
$database = "shanmugar";
// Create connection
$db = new mysqli($servername, $username, $password, $database);

// Check connection
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}


// server connection

// $servername = "localhost";
// $username = "adcbcoin_shanmugarfunds";
// $password = "![.H4p+nd7bM";
// $database = "adcbcoin_shanmugar";
// // Create connection
// $db = new mysqli($servername, $username, $password, $database);

// // Check connection
// if ($db->connect_error) {
//     die("Connection failed: " . $db->connect_error);
// }
?>