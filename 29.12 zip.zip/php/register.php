<?php
include "config.php";

echo ("done")
    ?>